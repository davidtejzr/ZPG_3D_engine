#pragma once
#include "Init.h"

class Shader;
class Camera
{
private:
	//Shader* m_shader;
	GLFWwindow* _window;
	glm::vec3 _position;
	glm::vec3 _orientation = glm::vec3(0.0f, 0.0f, -1.0f);
	glm::vec3 _up = glm::vec3(0.0f, 1.0f, 0.0f);
	int _width = 0;
	int _height = 0;
	float _speed = 0.1f;
	float _sensitivity = 100.0f;
	bool _firstClick = true;

public:
	Camera(GLFWwindow* window, glm::vec3 position);
	void lookAt(Shader* shader);
	void Controller();
};

